import { useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { clsx } from 'clsx';
import { Logo } from './components/Logo';
import { InstallerWindow } from './components/InstallerWindow';
import {
  ProgressDialogDemo,
  type ProgressDemoOptions,
} from './components/ProgressDialog';
import { ToastProvider } from './components/ToastProvider';
import { useToast } from './components/useToast';
import { ConfirmationDialog } from './components/ConfirmationDialog';
import { PreferencesPanel } from './components/PreferencesPanel';
import { GhostButton, PrimaryButton } from './components/ui';

/* ------------------------------------------------------------------ */
/*  Navigation                                                         */
/* ------------------------------------------------------------------ */

type View = 'installer' | 'operations' | 'notifications' | 'security' | 'preferences';

const NAV: { id: View; label: string; icon: ReactNode }[] = [
  {
    id: 'installer',
    label: 'Installer',
    icon: (
      <path d="M12 3v11M7.5 10L12 14.5 16.5 10M4 18.5h16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    id: 'operations',
    label: 'Operations',
    icon: (
      <path d="M12 3v18M7 8l5-5 5 5M7 16l5 5 5-5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    id: 'notifications',
    label: 'Notifications',
    icon: (
      <path d="M6 16v-5a6 6 0 1 1 12 0v5l1.5 3h-15L6 16zM10 21a2 2 0 0 0 4 0" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    id: 'security',
    label: 'Security',
    icon: (
      <path d="M12 3l7 3v5c0 4.5-3 8.5-7 10-4-1.5-7-5.5-7-10V6l7-3z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
    ),
  },
  {
    id: 'preferences',
    label: 'Preferences',
    icon: (
      <>
        <circle cx="12" cy="12" r="3.4" stroke="currentColor" strokeWidth="1.7" />
        <path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5 5l1.8 1.8M17.2 17.2L19 19M19 5l-1.8 1.8M6.8 17.2L5 19" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      </>
    ),
  },
];

/* ------------------------------------------------------------------ */
/*  Mock data                                                          */
/* ------------------------------------------------------------------ */

interface MockFile {
  name: string;
  size: string;
  kind: 'folder' | 'image' | 'doc' | 'code' | 'archive';
}

const PROJECT_FILES: MockFile[] = [
  { name: 'project-assets', size: '—', kind: 'folder' },
  { name: 'hero.png', size: '4.2 MB', kind: 'image' },
  { name: 'report-final.docx', size: '2.1 MB', kind: 'doc' },
  { name: 'credentials.txt', size: '0.4 KB', kind: 'doc' },
  { name: 'backup.zip', size: '14.8 MB', kind: 'archive' },
  { name: 'Header.tsx', size: '18 KB', kind: 'code' },
  { name: 'archive-2025.tar.gz', size: '96.4 MB', kind: 'archive' },
];

const SHRED_FILES = [
  { name: 'report-final.docx', size: '2.1 MB' },
  { name: 'credentials.txt', size: '0.4 KB' },
  { name: 'backup.zip', size: '14.8 MB' },
  { name: 'id-scan.pdf', size: '1.3 MB' },
  { name: 'keys.pem', size: '3.2 KB' },
  { name: 'tax-2025.pdf', size: '890 KB' },
  { name: 'notes-private.txt', size: '12 KB' },
  { name: 'wallet-backup.json', size: '48 KB' },
  { name: 'passport-scan.jpg', size: '3.7 MB' },
  { name: 'old-drive-image.img', size: '2.1 GB' },
];

function FileIcon({ kind }: { kind: MockFile['kind'] }) {
  const cls = 'h-4 w-4 shrink-0';
  if (kind === 'folder')
    return (
      <svg viewBox="0 0 24 24" className={clsx(cls, 'text-[#a3b27a]')} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round">
        <path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h5l2 2.5h8A1.5 1.5 0 0 1 21 9v9.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5v-12z" />
      </svg>
    );
  if (kind === 'image')
    return (
      <svg viewBox="0 0 24 24" className={clsx(cls, 'text-[#7a9cbf]')} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="16" rx="2" />
        <circle cx="9" cy="10" r="1.8" />
        <path d="M4 18l5-5 4 4 3-3 4 4" />
      </svg>
    );
  if (kind === 'archive')
    return (
      <svg viewBox="0 0 24 24" className={clsx(cls, 'text-[#d4a843]')} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round">
        <path d="M4 8l8-4 8 4v8l-8 4-8-4V8z" />
        <path d="M4 8l8 4 8-4M12 12v8" />
      </svg>
    );
  if (kind === 'code')
    return (
      <svg viewBox="0 0 24 24" className={clsx(cls, 'text-[#8cb369]')} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 7l-5 5 5 5M16 7l5 5-5 5" />
      </svg>
    );
  return (
    <svg viewBox="0 0 24 24" className={clsx(cls, 'text-[#7d8c5c]')} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round">
      <path d="M6 2.5h8L19 7.5v14H6v-19z" />
      <path d="M14 2.5v5h5" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  Views                                                              */
/* ------------------------------------------------------------------ */

function InstallerView() {
  const toast = useToast();
  const [runId, setRunId] = useState(0);
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6 px-6">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => setRunId((n) => n + 1)}
          className="flex items-center gap-2 rounded-lg border border-[rgba(200,212,162,0.12)] px-3.5 py-1.5 text-xs text-[#a3b27a] transition-colors hover:bg-[rgba(200,212,162,0.06)] hover:text-[#c8d4a2]"
        >
          <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 12a8 8 0 1 1-2.3-5.6M20 3v4h-4" />
          </svg>
          Replay installer
        </button>
        <span className="text-xs text-[#7d8c5c]">
          First-run experience — walk through all 5 steps.
        </span>
      </div>
      <InstallerWindow
        key={runId}
        onToast={(title, detail) => toast.success(title, { detail })}
      />
    </div>
  );
}

function OperationsView({
  onRun,
}: {
  onRun: (opts: ProgressDemoOptions) => void;
}) {
  const [selected, setSelected] = useState<Set<string>>(new Set(['project-assets']));
  const toggle = (name: string) =>
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });

  return (
    <div className="mx-auto flex h-full w-full max-w-[680px] flex-col px-6 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold tracking-tight text-[#c8d4a2]">Files</h2>
          <p className="mt-0.5 text-xs text-[#7d8c5c]">
            {selected.size} selected · select items, then run an operation
          </p>
        </div>
        <div className="flex items-center gap-2">
          <GhostButton
            className="px-4 py-2 text-xs"
            onClick={() =>
              onRun({
                type: 'compress',
                outputName: 'project-assets.zip',
                format: 'ZIP',
                compressionLevel: 'Normal compression',
                failAt: 62,
              })
            }
          >
            Compress (fail)
          </GhostButton>
          <PrimaryButton
            className="px-4 py-2 text-xs"
            onClick={() =>
              onRun({
                type: 'compress',
                outputName: 'project-assets.zip',
                format: 'ZIP',
                compressionLevel: 'Normal compression',
              })
            }
          >
            Compress
          </PrimaryButton>
        </div>
      </div>

      <div className="mt-5 overflow-hidden rounded-xl border border-[rgba(200,212,162,0.06)] bg-[rgba(200,212,162,0.03)]">
        {PROJECT_FILES.map((f, i) => (
          <button
            key={f.name}
            type="button"
            onClick={() => toggle(f.name)}
            className={clsx(
              'flex w-full items-center gap-3 px-4 py-2.5 text-left transition-colors hover:bg-[rgba(200,212,162,0.04)]',
              i !== PROJECT_FILES.length - 1 && 'border-b border-[rgba(200,212,162,0.04)]',
            )}
          >
            <span
              className={clsx(
                'flex h-4 w-4 shrink-0 items-center justify-center rounded-[5px] border transition-colors',
                selected.has(f.name)
                  ? 'border-[#8cb369] bg-[#8cb369]'
                  : 'border-[rgba(200,212,162,0.20)]',
              )}
            >
              {selected.has(f.name) && (
                <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="#1a1f14" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 8.5l3.2 3L13 4.5" />
                </svg>
              )}
            </span>
            <FileIcon kind={f.kind} />
            <span className="flex-1 truncate text-sm text-[#c8d4a2]">{f.name}</span>
            <span className="font-mono text-xs text-[#7d8c5c]">{f.size}</span>
          </button>
        ))}
      </div>

      <div className="mt-4 flex items-center gap-2">
        <GhostButton
          className="px-4 py-2 text-xs"
          onClick={() =>
            onRun({
              type: 'extract',
              outputName: 'archive-2025',
              format: 'TAR.GZ',
              compressionLevel: 'Extracting',
            })
          }
        >
          Extract
        </GhostButton>
        <GhostButton
          className="px-4 py-2 text-xs"
          onClick={() =>
            onRun({
              type: 'split',
              outputName: 'backup.part001.zip',
              format: 'ZIP',
              compressionLevel: 'Split into 50 MB parts',
            })
          }
        >
          Split
        </GhostButton>
        <p className="ml-auto text-xs text-[#7d8c5c]">
          The progress dialog supports compress, extract, split & shred.
        </p>
      </div>
    </div>
  );
}

function NotificationsView() {
  const toast = useToast();
  const demos = [
    {
      label: 'Copy path',
      run: () =>
        toast.success('Path copied to clipboard', {
          detail: 'C:\\Users\\you\\Documents\\project-assets',
        }),
    },
    {
      label: 'Unblock complete',
      run: () =>
        toast.success('File unblocked', { detail: 'backup.zip is safe to open' }),
    },
    {
      label: 'Operation failed',
      run: () =>
        toast.error('Operation failed', {
          detail: 'Permission denied (EACCES)',
          duration: 5000,
        }),
    },
    {
      label: 'Update available',
      run: () =>
        toast.info('Update available', {
          detail: 'ReformAny v1.1.0 — 3 new features',
        }),
    },
    {
      label: 'Disk space low',
      run: () =>
        toast.warning('Disk space low', {
          detail: 'Only 4.1 GB remaining on C:',
          duration: 6000,
        }),
    },
  ];

  return (
    <div className="mx-auto flex h-full w-full max-w-[680px] flex-col px-6 py-8">
      <h2 className="text-lg font-semibold tracking-tight text-[#c8d4a2]">Notifications</h2>
      <p className="mt-0.5 text-xs text-[#7d8c5c]">
        Transient confirmations appear bottom-center. Fire a few to see them stack.
      </p>
      <div className="mt-6 grid grid-cols-2 gap-3">
        {demos.map((d) => (
          <button
            key={d.label}
            type="button"
            onClick={d.run}
            className="flex items-center justify-between rounded-xl border border-[rgba(200,212,162,0.06)] bg-[rgba(200,212,162,0.03)] px-4 py-3.5 text-left text-sm text-[#a3b27a] transition-all hover:border-[rgba(200,212,162,0.14)] hover:bg-[rgba(200,212,162,0.06)] hover:text-[#c8d4a2] active:scale-[0.98]"
          >
            {d.label}
            <svg viewBox="0 0 16 16" className="h-3.5 w-3.5 text-[#7d8c5c]" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2.5 8h11M9.5 3.5L14 8l-4.5 4.5" />
            </svg>
          </button>
        ))}
      </div>
      <p className="mt-6 text-xs leading-relaxed text-[#7d8c5c]">
        Max 3 toasts stack upward with an 8px gap. Each carries a 1px
        time-remaining bar in its variant color and auto-dismisses after 3
        seconds (configurable per toast).
      </p>
    </div>
  );
}

function SecurityView({ onShred }: { onShred: () => void }) {
  return (
    <div className="mx-auto flex h-full w-full max-w-[680px] flex-col px-6 py-8">
      <h2 className="text-lg font-semibold tracking-tight text-[#c8d4a2]">Secure shred</h2>
      <p className="mt-0.5 text-xs text-[#7d8c5c]">
        Irreversible secure delete using 3-pass DoD overwrite.
      </p>

      <div className="mt-6 rounded-xl border border-[rgba(212,168,67,0.18)] bg-[rgba(212,168,67,0.04)] p-4">
        <div className="flex items-start gap-3">
          <svg viewBox="0 0 24 24" className="mt-0.5 h-5 w-5 shrink-0 text-[#d4a843]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3.5L22 20H2L12 3.5z" />
            <path d="M12 10v4.5" />
            <circle cx="12" cy="17.2" r="0.7" fill="currentColor" stroke="none" />
          </svg>
          <p className="text-sm leading-relaxed text-[#a3b27a]">
            Shredded files are overwritten three times and cannot be recovered —
            not by ReformAny, not by anyone. The confirmation dialog requires
            typing{' '}
            <span className="font-mono text-[#c8d4a2]">"SHRED"</span> before the
            destructive action unlocks.
          </p>
        </div>
      </div>

      <div className="mt-5 overflow-hidden rounded-xl border border-[rgba(200,212,162,0.06)] bg-[rgba(200,212,162,0.03)]">
        {SHRED_FILES.slice(0, 5).map((f, i) => (
          <div
            key={f.name}
            className={clsx(
              'flex items-center gap-3 px-4 py-2.5',
              i !== 4 && 'border-b border-[rgba(200,212,162,0.04)]',
            )}
          >
            <FileIcon kind="doc" />
            <span className="flex-1 truncate text-sm text-[#c8d4a2]">{f.name}</span>
            <span className="font-mono text-xs text-[#7d8c5c]">{f.size}</span>
          </div>
        ))}
        <p className="px-4 py-2.5 text-xs text-[#7d8c5c]">and 5 more files</p>
      </div>

      <div className="mt-5">
        <button
          type="button"
          onClick={onShred}
          className="rounded-lg bg-[#c75d5d] px-5 py-2.5 text-sm font-medium text-[#1a1f14] transition-all duration-150 hover:bg-[#d46b6b] active:scale-[0.97]"
        >
          Shred 10 files…
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Shell                                                              */
/* ------------------------------------------------------------------ */

function Shell() {
  const toast = useToast();
  const [view, setView] = useState<View>('installer');
  const [progressOpen, setProgressOpen] = useState(false);
  const [progressOpts, setProgressOpts] = useState<ProgressDemoOptions>({
    type: 'compress',
    outputName: 'project-assets.zip',
    format: 'ZIP',
    compressionLevel: 'Normal compression',
  });
  const [confirmOpen, setConfirmOpen] = useState(false);

  const runOperation = (opts: ProgressDemoOptions) => {
    setProgressOpts(opts);
    setProgressOpen(true);
  };

  return (
    <div className="flex h-full">
      {/* Ambient backdrop */}
      <div className="pointer-events-none fixed inset-0">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(900px 500px at 15% -10%, rgba(200,212,162,0.06), transparent 60%), radial-gradient(800px 500px at 95% 110%, rgba(140,179,105,0.05), transparent 60%)',
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage:
              'radial-gradient(rgba(200,212,162,0.05) 1px, transparent 1px)',
            backgroundSize: '26px 26px',
          }}
        />
      </div>

      {/* Sidebar */}
      <aside className="relative z-10 flex w-[232px] shrink-0 flex-col border-r border-[rgba(200,212,162,0.06)] bg-[rgba(35,42,28,0.55)] backdrop-blur-xl">
        <div className="flex items-center gap-3 px-5 pb-5 pt-6">
          <Logo size={32} />
          <div>
            <p className="text-sm font-semibold tracking-tight text-[#c8d4a2]">ReformAny</p>
            <p className="text-[11px] text-[#7d8c5c]">Component Lab</p>
          </div>
        </div>

        <nav className="flex flex-col gap-0.5 px-3">
          {NAV.map((item) => {
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={clsx(
                  'relative flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition-colors duration-150',
                  active
                    ? 'bg-[rgba(200,212,162,0.08)] text-[#c8d4a2]'
                    : 'text-[#7d8c5c] hover:bg-[rgba(200,212,162,0.04)] hover:text-[#a3b27a]',
                )}
              >
                {active && (
                  <motion.span
                    layoutId="nav-active-bar"
                    className="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-[#c8d4a2]"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
                <svg viewBox="0 0 24 24" className="h-[18px] w-[18px] shrink-0" fill="none">
                  {item.icon}
                </svg>
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto px-5 pb-5">
          <p className="text-[11px] text-[#7d8c5c]">v1.0.0 · 12.4 MB</p>
          <p className="mt-1 text-[11px] leading-relaxed text-[#7d8c5c]/70">
            Olive-earth design system. Five production components, one shell.
          </p>
        </div>
      </aside>

      {/* Main */}
      <main className="relative z-10 min-w-0 flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.22, ease: [0.25, 0.1, 0.25, 1] }}
            className="h-full"
          >
            {view === 'installer' && <InstallerView />}
            {view === 'operations' && <OperationsView onRun={runOperation} />}
            {view === 'notifications' && <NotificationsView />}
            {view === 'security' && <SecurityView onShred={() => setConfirmOpen(true)} />}
            {view === 'preferences' && <PreferencesPanel />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Global dialogs */}
      <ProgressDialogDemo
        open={progressOpen}
        options={progressOpts}
        onClose={() => setProgressOpen(false)}
        onToast={(title, detail) => toast.success(title, { detail })}
      />
      <ConfirmationDialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        onConfirm={() => {
          setConfirmOpen(false);
          toast.success('Files shredded securely', {
            detail: '10 files · 3-pass DoD overwrite',
          });
        }}
        files={SHRED_FILES}
      />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  );
}
