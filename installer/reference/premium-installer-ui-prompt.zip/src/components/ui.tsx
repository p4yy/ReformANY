import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { clsx } from 'clsx';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
}

/** Primary action — sage fill, dark text, tactile press. */
export function PrimaryButton({ children, className, ...rest }: ButtonProps) {
  return (
    <button
      {...rest}
      className={clsx(
        'inline-flex items-center justify-center gap-2 rounded-lg bg-[#c8d4a2] px-6 py-2.5 text-sm font-medium text-[#1a1f14]',
        'transition-all duration-150 hover:bg-[#d4e0ae] active:scale-[0.97]',
        'disabled:pointer-events-none disabled:opacity-40',
        className,
      )}
    >
      {children}
    </button>
  );
}

/** Ghost action — transparent with a sage hairline border. */
export function GhostButton({ children, className, ...rest }: ButtonProps) {
  return (
    <button
      {...rest}
      className={clsx(
        'inline-flex items-center justify-center gap-2 rounded-lg border border-[rgba(200,212,162,0.12)] bg-transparent px-5 py-2.5 text-sm font-medium text-[#a3b27a]',
        'transition-all duration-150 hover:border-[rgba(200,212,162,0.20)] hover:bg-[rgba(200,212,162,0.06)] hover:text-[#c8d4a2] active:scale-[0.97]',
        'disabled:pointer-events-none disabled:opacity-40',
        className,
      )}
    >
      {children}
    </button>
  );
}

/** Small pill badge used for format / level metadata. */
export function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={clsx(
        'inline-flex items-center rounded-full border border-[rgba(200,212,162,0.06)] bg-[rgba(200,212,162,0.08)] px-2.5 py-0.5 text-xs text-[#a3b27a]',
        className,
      )}
    >
      {children}
    </span>
  );
}
