import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Badge, GhostButton, PrimaryButton } from './ui';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type OperationState =
  | 'preparing'
  | 'active'
  | 'paused'
  | 'cancelling'
  | 'complete'
  | 'error';

export type OperationType = 'compress' | 'extract' | 'split' | 'shred';

export interface ProgressDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCancel: () => void;
  onRetry?: () => void;
  onOpenFolder?: () => void;
  onTogglePause?: () => void;
  operation: {
    type: OperationType;
    format?: string;
    compressionLevel?: string;
    outputName: string;
  };
  progress: {
    state: OperationState;
    percent: number;
    currentFile: string;
    processedBytes: number;
    totalBytes: number;
    filesDone: number;
    filesTotal: number;
    speedBps: number;
    etaSeconds: number;
    elapsedSeconds: number;
    errorMessage?: string;
    compressionRatio?: number;
  };
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const OP_VERBS: Record<OperationType, { active: string; done: string; failed: string }> = {
  compress: { active: 'Compressing files...', done: 'Compression complete', failed: 'Compression failed' },
  extract: { active: 'Extracting archive...', done: 'Extraction complete', failed: 'Extraction failed' },
  split: { active: 'Splitting file...', done: 'Split complete', failed: 'Split failed' },
  shred: { active: 'Shredding files...', done: 'Shred complete', failed: 'Shred failed' },
};

function formatBytes(b: number): string {
  if (b >= 1e9) return `${(b / 1e9).toFixed(1)} GB`;
  if (b >= 1e6) return `${(b / 1e6).toFixed(1)} MB`;
  if (b >= 1e3) return `${(b / 1e3).toFixed(1)} KB`;
  return `${Math.round(b)} B`;
}

function formatSpeed(bps: number): string {
  if (bps >= 1e6) return `${(bps / 1e6).toFixed(1)} MB/s`;
  return `${(bps / 1e3).toFixed(0)} KB/s`;
}

function formatElapsed(s: number): string {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

/** Left-truncate a path so the filename stays visible: ...components/Header.tsx */
function truncateLeft(path: string, max = 34): string {
  if (path.length <= max) return path;
  return `...${path.slice(-(max - 3))}`;
}

/* ------------------------------------------------------------------ */
/*  Header status icon                                                 */
/* ------------------------------------------------------------------ */

function StatusIcon({ state }: { state: OperationState }) {
  if (state === 'complete') {
    return (
      <motion.span
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 16 }}
        className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(140,179,105,0.4)] bg-[rgba(140,179,105,0.12)]"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4">
          <motion.path
            d="M20 6L9 17l-5-5"
            fill="none"
            stroke="#8cb369"
            strokeWidth="2.6"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 0.5, ease: 'easeOut', delay: 0.1 }}
          />
        </svg>
      </motion.span>
    );
  }

  if (state === 'error') {
    return (
      <motion.span
        initial={{ x: 0 }}
        animate={{ x: [0, -4, 4, -3, 3, 0] }}
        transition={{ duration: 0.4 }}
        className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(199,93,93,0.4)] bg-[rgba(199,93,93,0.12)]"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="#c75d5d" strokeWidth="2.6" strokeLinecap="round">
          <path d="M6 6l12 12M18 6L6 18" />
        </svg>
      </motion.span>
    );
  }

  if (state === 'paused') {
    return (
      <span className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(212,168,67,0.4)] bg-[rgba(212,168,67,0.10)]">
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="#d4a843">
          <rect x="6" y="5" width="4" height="14" rx="1" />
          <rect x="14" y="5" width="4" height="14" rx="1" />
        </svg>
      </span>
    );
  }

  if (state === 'cancelling') {
    return (
      <span className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(200,212,162,0.15)] bg-[rgba(200,212,162,0.05)]">
        <svg viewBox="0 0 24 24" className="h-4 w-4 animate-spin-slow" fill="none" stroke="#a3b27a" strokeWidth="2.4" strokeLinecap="round">
          <path d="M12 3a9 9 0 1 0 9 9" />
        </svg>
      </span>
    );
  }

  // active / preparing — rotating gear
  return (
    <span className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(200,212,162,0.15)] bg-[rgba(200,212,162,0.05)]">
      <svg viewBox="0 0 24 24" className="h-4 w-4 animate-spin-slow" fill="none" stroke="#c8d4a2" strokeWidth="2" strokeLinecap="round">
        <circle cx="12" cy="12" r="3.2" />
        <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1" />
      </svg>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  ProgressDialog                                                     */
/* ------------------------------------------------------------------ */

export function ProgressDialog({
  isOpen,
  onClose,
  onCancel,
  onRetry,
  onOpenFolder,
  onTogglePause,
  operation,
  progress,
}: ProgressDialogProps) {
  const [confirmCancel, setConfirmCancel] = useState(false);
  const confirmTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { state, percent } = progress;
  const verbs = OP_VERBS[operation.type];
  const terminal = state === 'complete' || state === 'error';
  const running = state === 'active' || state === 'preparing' || state === 'paused';

  const title =
    state === 'complete'
      ? verbs.done
      : state === 'error'
        ? verbs.failed
        : state === 'cancelling'
          ? 'Cancelling...'
          : state === 'paused'
            ? 'Paused'
            : verbs.active;

  /* Reset cancel-confirmation whenever the dialog closes or state changes */
  useEffect(() => {
    if (!isOpen) setConfirmCancel(false);
  }, [isOpen]);

  useEffect(() => {
    if (confirmCancel) {
      confirmTimer.current = setTimeout(() => setConfirmCancel(false), 3000);
    }
    return () => {
      if (confirmTimer.current) clearTimeout(confirmTimer.current);
    };
  }, [confirmCancel]);

  /* Escape closes terminal dialogs */
  useEffect(() => {
    if (!isOpen || !terminal) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, terminal, onClose]);

  const fillColor =
    state === 'complete'
      ? '#8cb369'
      : state === 'error'
        ? '#c75d5d'
        : 'linear-gradient(90deg, #8cb369, #c8d4a2)';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={() => terminal && onClose()}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.97, opacity: 0, transition: { duration: 0.15, ease: 'easeOut' } }}
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-window noise w-[480px] max-w-[calc(100vw-32px)] overflow-hidden p-6"
          >
            {/* Header */}
            <div className="flex items-center gap-3">
              <StatusIcon state={state} />
              <h2 className="flex-1 text-base font-semibold tracking-tight text-[#c8d4a2]">
                {title}
              </h2>
              {(state === 'active' || state === 'paused') && onTogglePause && (
                <button
                  type="button"
                  aria-label={state === 'paused' ? 'Resume' : 'Pause'}
                  onClick={onTogglePause}
                  className="flex h-7 w-7 items-center justify-center rounded-md text-[#7d8c5c] transition-colors hover:bg-[rgba(200,212,162,0.08)] hover:text-[#c8d4a2]"
                >
                  {state === 'paused' ? (
                    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                      <path d="M7 4.5v15l13-7.5-13-7.5z" />
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                      <rect x="6" y="5" width="4" height="14" rx="1" />
                      <rect x="14" y="5" width="4" height="14" rx="1" />
                    </svg>
                  )}
                </button>
              )}
              {terminal && (
                <button
                  type="button"
                  aria-label="Close"
                  onClick={onClose}
                  className="flex h-7 w-7 items-center justify-center rounded-md text-[#7d8c5c] transition-colors hover:bg-[rgba(200,212,162,0.08)] hover:text-[#c8d4a2]"
                >
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M6 6l12 12M18 6L6 18" />
                  </svg>
                </button>
              )}
            </div>

            {/* Output + badges */}
            <div className="mt-5">
              <p className="truncate text-sm font-medium text-[#c8d4a2]">
                {operation.outputName}
              </p>
              <div className="mt-2 flex gap-1.5">
                {operation.format && <Badge>{operation.format}</Badge>}
                {operation.compressionLevel && (
                  <Badge>{operation.compressionLevel}</Badge>
                )}
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-5 flex items-center gap-3">
              <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-[rgba(200,212,162,0.06)]">
                <div
                  className="relative h-full overflow-hidden rounded-full transition-[width] duration-300 ease-out"
                  style={{ width: `${Math.min(100, percent)}%`, background: fillColor }}
                >
                  {state === 'active' && (
                    <span
                      className="absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-white/25 to-transparent"
                      style={{ animation: 'shimmer-slide 1.8s linear infinite' }}
                    />
                  )}
                </div>
              </div>
              <span className="w-11 text-right font-mono text-sm tabular-nums text-[#c8d4a2]">
                {Math.floor(percent)}%
              </span>
            </div>

            {/* Detail panel */}
            <div className="mt-4 rounded-lg border border-[rgba(200,212,162,0.04)] bg-[rgba(0,0,0,0.2)] p-3">
              {state === 'error' ? (
                <p className="font-mono text-xs leading-relaxed text-[#c75d5d]">
                  {progress.errorMessage ?? 'Unknown error'}
                </p>
              ) : state === 'complete' ? (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-[#7d8c5c]">
                      {progress.filesTotal} files · {formatBytes(progress.totalBytes)} →{' '}
                      {formatBytes(progress.processedBytes)}
                    </p>
                    <p className="mt-1 text-xs text-[#7d8c5c]">
                      Finished in {formatElapsed(progress.elapsedSeconds)}
                    </p>
                  </div>
                  {progress.compressionRatio != null && (
                    <span className="text-3xl font-light tabular-nums text-[#8cb369]">
                      {progress.compressionRatio}%
                    </span>
                  )}
                </div>
              ) : (
                <>
                  <div className="flex h-4 items-center">
                    <AnimatePresence mode="wait">
                      <motion.p
                        key={progress.currentFile}
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        transition={{ duration: 0.18 }}
                        className="truncate font-mono text-xs text-[#a3b27a]"
                      >
                        {truncateLeft(progress.currentFile)}
                      </motion.p>
                    </AnimatePresence>
                  </div>
                  <div className="mt-2 space-y-1 text-xs text-[#7d8c5c]">
                    <p>
                      {formatBytes(progress.processedBytes)} of{' '}
                      {formatBytes(progress.totalBytes)} processed
                    </p>
                    <p>
                      Speed: {formatSpeed(progress.speedBps)}
                      <span className="mx-2 text-[rgba(200,212,162,0.25)]">·</span>
                      ETA: ~{Math.max(0, Math.round(progress.etaSeconds))} seconds
                    </p>
                  </div>
                </>
              )}
            </div>

            {/* Stats footer */}
            <div className="mt-4 flex items-center justify-between text-xs text-[#7d8c5c]">
              <span>
                Files: {progress.filesDone}/{progress.filesTotal}
              </span>
              <span>Elapsed: {formatElapsed(progress.elapsedSeconds)}</span>
            </div>

            {/* Actions */}
            <div className="mt-5 flex items-center justify-end gap-2">
              {running && !confirmCancel && (
                <GhostButton onClick={() => setConfirmCancel(true)}>Cancel</GhostButton>
              )}

              {running && confirmCancel && (
                <motion.div
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center gap-2"
                >
                  <span className="mr-1 text-xs text-[#7d8c5c]">Are you sure?</span>
                  <button
                    type="button"
                    onClick={onCancel}
                    className="rounded-lg bg-[#c75d5d] px-4 py-2.5 text-sm font-medium text-[#1a1f14] transition-all duration-150 hover:bg-[#d46b6b] active:scale-[0.97]"
                  >
                    Yes, cancel
                  </button>
                  <GhostButton onClick={() => setConfirmCancel(false)} className="px-4">
                    No
                  </GhostButton>
                </motion.div>
              )}

              {state === 'cancelling' && (
                <span className="text-xs text-[#7d8c5c]">Cleaning up…</span>
              )}

              {state === 'error' && (
                <>
                  <GhostButton onClick={onClose}>Dismiss</GhostButton>
                  <PrimaryButton onClick={onRetry}>Retry</PrimaryButton>
                </>
              )}

              {state === 'complete' && (
                <div className="flex w-full flex-col items-end gap-2">
                  <div className="flex items-center gap-2">
                    <GhostButton onClick={onClose}>Close</GhostButton>
                    <PrimaryButton onClick={onClose}>Done</PrimaryButton>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenFolder}
                    className="text-xs text-[#7d8c5c] underline decoration-[rgba(200,212,162,0.25)] underline-offset-4 transition-colors hover:text-[#c8d4a2]"
                  >
                    Open in folder
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ------------------------------------------------------------------ */
/*  Demo wrapper — simulates an 8s operation with realistic files      */
/* ------------------------------------------------------------------ */

const DEMO_FILES = [
  'src/components/Header.tsx',
  'src/components/Sidebar.tsx',
  'src/components/ProgressDialog.tsx',
  'src/components/InstallerWindow.tsx',
  'src/lib/compressor.ts',
  'src/lib/archive.ts',
  'src/lib/shredder.ts',
  'src/hooks/useOperation.ts',
  'assets/hero.png',
  'assets/logo.svg',
  'assets/textures/noise.png',
  'docs/getting-started.md',
  'docs/api-reference.md',
  'tests/compressor.test.ts',
  'tests/archive.test.ts',
  'dist/reformany.exe',
  'dist/reformany.pdb',
  'dist/libarchive.dll',
  'dist/zstd.dll',
  'dist/lz4.dll',
  'dist/reformany-shell.dll',
  'dist/reformany-ui.pak',
  'dictionaries/en-US.dict',
  'dictionaries/de-DE.dict',
];

export interface ProgressDemoOptions {
  type: OperationType;
  outputName: string;
  format?: string;
  compressionLevel?: string;
  failAt?: number; // percent at which to fail (demo)
  durationMs?: number;
}

export function ProgressDialogDemo({
  open,
  options,
  onClose,
  onToast,
}: {
  open: boolean;
  options: ProgressDemoOptions;
  onClose: () => void;
  onToast?: (title: string, detail?: string) => void;
}) {
  const totalBytes = 18.7 * 1024 * 1024;
  const filesTotal = 128;
  const [progress, setProgress] = useState<ProgressDialogProps['progress']>({
    state: 'preparing',
    percent: 0,
    currentFile: DEMO_FILES[0],
    processedBytes: 0,
    totalBytes,
    filesDone: 0,
    filesTotal,
    speedBps: 0,
    etaSeconds: 0,
    elapsedSeconds: 0,
  });
  const runRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const stateRef = useRef<OperationState>('preparing');
  const simRef = useRef({ startedAt: 0, lastBytes: 0, lastT: 0, pausedAt: 0 });

  const stopTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const tick = (runId: number) => {
    if (runRef.current !== runId) return;
    const duration = options.durationMs ?? 8000;
    const sim = simRef.current;
    const now = performance.now();
    const t = Math.min(1, (now - sim.startedAt) / duration);
    // ease: quick start, steady middle, gentle finish
    const eased = t < 0.15 ? t * 1.35 : 0.2025 + (t - 0.15) * 0.94;
    const percent = Math.min(100, eased * 100);
    const bytes = (totalBytes * percent) / 100;

    const dt = (now - sim.lastT) / 1000;
    const speed = dt > 0 ? (bytes - sim.lastBytes) / dt : 0;
    sim.lastBytes = bytes;
    sim.lastT = now;

    const fileIdx = Math.min(
      DEMO_FILES.length - 1,
      Math.floor((percent / 100) * DEMO_FILES.length),
    );

    if (options.failAt != null && percent >= options.failAt) {
      stopTimer();
      stateRef.current = 'error';
      setProgress((p) => ({
        ...p,
        state: 'error',
        percent,
        processedBytes: bytes,
        currentFile: DEMO_FILES[fileIdx],
        filesDone: Math.floor((percent / 100) * filesTotal),
        speedBps: speed,
        elapsedSeconds: (now - sim.startedAt) / 1000,
        errorMessage: 'Disk write failed: permission denied (EACCES) — C:\\Users\\you\\Documents\\project-assets.zip',
      }));
      return;
    }

    if (t >= 1) {
      stopTimer();
      stateRef.current = 'complete';
      setProgress({
        state: 'complete',
        percent: 100,
        currentFile: DEMO_FILES[DEMO_FILES.length - 1],
        processedBytes: totalBytes * 0.225,
        totalBytes,
        filesDone: filesTotal,
        filesTotal,
        speedBps: 0,
        etaSeconds: 0,
        elapsedSeconds: (now - sim.startedAt) / 1000,
        compressionRatio: 77,
      });
      onToast?.('Compression complete', 'project-assets.zip · 18.7 MB → 4.2 MB');
      return;
    }

    setProgress({
      state: 'active',
      percent,
      currentFile: DEMO_FILES[fileIdx],
      processedBytes: bytes,
      totalBytes,
      filesDone: Math.floor((percent / 100) * filesTotal),
      filesTotal,
      speedBps: Math.max(0, speed * (0.85 + Math.random() * 0.3)),
      etaSeconds: ((100 - percent) / 100) * duration / 1000,
      elapsedSeconds: (now - sim.startedAt) / 1000,
    });
  };

  const start = () => {
    const runId = ++runRef.current;
    stopTimer();
    const now = performance.now();
    simRef.current = { startedAt: now, lastBytes: 0, lastT: now, pausedAt: 0 };
    stateRef.current = 'active';
    setProgress({
      state: 'active',
      percent: 0,
      currentFile: DEMO_FILES[0],
      processedBytes: 0,
      totalBytes,
      filesDone: 0,
      filesTotal,
      speedBps: 0,
      etaSeconds: (options.durationMs ?? 8000) / 1000,
      elapsedSeconds: 0,
    });
    intervalRef.current = setInterval(() => tick(runId), 100);
  };

  const togglePause = () => {
    if (stateRef.current === 'active') {
      stopTimer();
      simRef.current.pausedAt = performance.now();
      stateRef.current = 'paused';
      setProgress((p) => ({ ...p, state: 'paused', speedBps: 0 }));
    } else if (stateRef.current === 'paused') {
      const runId = runRef.current;
      const now = performance.now();
      simRef.current.startedAt += now - simRef.current.pausedAt;
      simRef.current.lastT = now;
      stateRef.current = 'active';
      setProgress((p) => ({ ...p, state: 'active' }));
      intervalRef.current = setInterval(() => tick(runId), 100);
    }
  };

  useEffect(() => {
    if (!open) return;
    start();
    return () => {
      runRef.current++;
      stopTimer();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, options]);

  const handleCancel = () => {
    runRef.current++;
    stopTimer();
    stateRef.current = 'cancelling';
    setProgress((p) => ({ ...p, state: 'cancelling' }));
    setTimeout(() => {
      onClose();
      onToast?.('Operation cancelled', 'Partial output was removed.');
    }, 900);
  };

  return (
    <ProgressDialog
      isOpen={open}
      onClose={onClose}
      onCancel={handleCancel}
      onRetry={start}
      onTogglePause={togglePause}
      onOpenFolder={() => onToast?.('Opened in Explorer', 'C:\\Users\\you\\Documents')}
      operation={{
        type: options.type,
        format: options.format,
        compressionLevel: options.compressionLevel,
        outputName: options.outputName,
      }}
      progress={progress}
    />
  );
}
