import {
  createContext,
  useCallback,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { AnimatePresence, motion } from 'framer-motion';

export type ToastVariant = 'success' | 'error' | 'info' | 'warning';

export interface ToastOptions {
  detail?: string;
  duration?: number;
}

interface ToastData {
  id: number;
  variant: ToastVariant;
  title: string;
  detail?: string;
  duration: number;
}

interface ToastApi {
  success: (title: string, opts?: ToastOptions) => void;
  error: (title: string, opts?: ToastOptions) => void;
  info: (title: string, opts?: ToastOptions) => void;
  warning: (title: string, opts?: ToastOptions) => void;
}

export const ToastContext = createContext<ToastApi | null>(null);

const VARIANT_COLORS: Record<ToastVariant, string> = {
  success: '#8cb369',
  error: '#c75d5d',
  info: '#7a9cbf',
  warning: '#d4a843',
};

function ToastIcon({ variant }: { variant: ToastVariant }) {
  const color = VARIANT_COLORS[variant];
  if (variant === 'success') {
    return (
      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none">
        <motion.path
          d="M20 6L9 17l-5-5"
          stroke={color}
          strokeWidth="2.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.4, ease: 'easeOut', delay: 0.1 }}
        />
      </svg>
    );
  }
  if (variant === 'error') {
    return (
      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none" stroke={color} strokeWidth="2.6" strokeLinecap="round">
        <path d="M6 6l12 12M18 6L6 18" />
      </svg>
    );
  }
  if (variant === 'info') {
    return (
      <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round">
        <circle cx="12" cy="12" r="9" />
        <path d="M12 11v5" />
        <circle cx="12" cy="7.6" r="0.6" fill={color} stroke="none" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 3.5L22 20H2L12 3.5z" />
      <path d="M12 10v4.5" />
      <circle cx="12" cy="17.2" r="0.6" fill={color} stroke="none" />
    </svg>
  );
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastData[]>([]);
  const idRef = useRef(0);

  const dismiss = useCallback((id: number) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const push = useCallback(
    (variant: ToastVariant, title: string, opts?: ToastOptions) => {
      const id = ++idRef.current;
      const duration = opts?.duration ?? 3000;
      setToasts((t) => [...t.slice(-2), { id, variant, title, detail: opts?.detail, duration }]);
      setTimeout(() => dismiss(id), duration);
    },
    [dismiss],
  );

  const api: ToastApi = {
    success: (title, opts) => push('success', title, opts),
    error: (title, opts) => push('error', title, opts),
    info: (title, opts) => push('info', title, opts),
    warning: (title, opts) => push('warning', title, opts),
  };

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pointer-events-none fixed bottom-6 left-1/2 z-[100] flex -translate-x-1/2 flex-col items-center gap-2">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 5, transition: { duration: 0.2 } }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              className="glass-window noise pointer-events-auto group relative flex w-auto max-w-[360px] items-start gap-2.5 overflow-hidden rounded-xl px-4 pb-3 pt-3"
            >
              <div className="mt-[1px]">
                <ToastIcon variant={toast.variant} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium leading-tight text-[#c8d4a2]">
                  {toast.title}
                </p>
                {toast.detail && (
                  <p className="mt-0.5 truncate text-xs text-[#7d8c5c]">
                    {toast.detail}
                  </p>
                )}
              </div>
              <button
                type="button"
                aria-label="Dismiss"
                onClick={() => dismiss(toast.id)}
                className="ml-1 mt-[1px] flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#7d8c5c] opacity-0 transition-all hover:bg-[rgba(200,212,162,0.08)] hover:text-[#c8d4a2] group-hover:opacity-100"
              >
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                  <path d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
              {/* Time-remaining bar */}
              <motion.span
                initial={{ scaleX: 1 }}
                animate={{ scaleX: 0 }}
                transition={{ duration: toast.duration / 1000, ease: 'linear' }}
                style={{ background: VARIANT_COLORS[toast.variant], opacity: 0.2 }}
                className="absolute bottom-0 left-0 h-px w-full origin-left"
              />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}
