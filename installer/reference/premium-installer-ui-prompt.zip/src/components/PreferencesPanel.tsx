import { useState, type ReactNode } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { clsx } from 'clsx';
import { Logo } from './Logo';
import { ToggleRow } from './Toggle';
import { GhostButton, PrimaryButton } from './ui';
import { useToast } from './useToast';

/* ------------------------------------------------------------------ */
/*  Settings model                                                     */
/* ------------------------------------------------------------------ */

interface Settings {
  theme: string;
  accent: string;
  animations: boolean;
  language: string;
  defaultFormat: string;
  compressionLevel: number;
  threadCount: number;
  tempDir: string;
  afterCompress: string;
  soundEffects: boolean;
  contextMenu: boolean;
  addToPath: boolean;
  defaultApp: boolean;
  associations: Record<string, boolean>;
  loggingLevel: string;
  autoUpdate: boolean;
  telemetry: boolean;
}

const DEFAULT_SETTINGS: Settings = {
  theme: 'Auto',
  accent: '#c8d4a2',
  animations: true,
  language: 'English (US)',
  defaultFormat: 'ZIP',
  compressionLevel: 6,
  threadCount: 8,
  tempDir: 'C:\\Users\\you\\AppData\\Local\\Temp\\ReformAny',
  afterCompress: 'Close dialog',
  soundEffects: false,
  contextMenu: true,
  addToPath: true,
  defaultApp: true,
  associations: { ZIP: true, '7z': true, TAR: true, RAR: false, GZ: true },
  loggingLevel: 'Info',
  autoUpdate: true,
  telemetry: false,
};

type SectionId = 'general' | 'compression' | 'integration' | 'advanced' | 'about';

const SECTIONS: { id: SectionId; label: string; icon: ReactNode }[] = [
  {
    id: 'general',
    label: 'General',
    icon: (
      <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    ),
  },
  {
    id: 'compression',
    label: 'Compression',
    icon: (
      <path d="M12 3v18M7 8l5-5 5 5M7 16l5 5 5-5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    id: 'integration',
    label: 'Integration',
    icon: (
      <path d="M9 3H4v5M15 3h5v5M9 21H4v-5M15 21h5v-5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    ),
  },
  {
    id: 'advanced',
    label: 'Advanced',
    icon: (
      <>
        <circle cx="12" cy="12" r="3.4" stroke="currentColor" strokeWidth="1.7" />
        <path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5 5l1.8 1.8M17.2 17.2L19 19M19 5l-1.8 1.8M6.8 17.2L5 19" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      </>
    ),
  },
  {
    id: 'about',
    label: 'About',
    icon: (
      <>
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.7" />
        <path d="M12 11v5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
        <circle cx="12" cy="7.6" r="0.8" fill="currentColor" />
      </>
    ),
  },
];

/* ------------------------------------------------------------------ */
/*  Small controls                                                     */
/* ------------------------------------------------------------------ */

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="rounded-xl border border-[rgba(200,212,162,0.06)] bg-[rgba(200,212,162,0.03)] p-5">
      <h3 className="mb-4 text-xs font-semibold uppercase tracking-widest text-[#7d8c5c]">
        {title}
      </h3>
      <div className="flex flex-col gap-4">{children}</div>
    </section>
  );
}

function Row({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-medium text-[#c8d4a2]">{label}</p>
        {description && (
          <p className="mt-0.5 text-xs leading-relaxed text-[#7d8c5c]">{description}</p>
        )}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Dropdown({
  value,
  options,
  onChange,
}: {
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={clsx(
          'flex h-8 min-w-[132px] items-center justify-between gap-2 rounded-lg border bg-[rgba(0,0,0,0.22)] px-3 text-sm text-[#c8d4a2] transition-colors',
          open
            ? 'border-[rgba(200,212,162,0.28)]'
            : 'border-[rgba(200,212,162,0.10)] hover:border-[rgba(200,212,162,0.20)]',
        )}
      >
        {value}
        <svg
          viewBox="0 0 16 16"
          className={clsx('h-3.5 w-3.5 text-[#7d8c5c] transition-transform duration-200', open && 'rotate-180')}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M4 6l4 4 4-4" />
        </svg>
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
            <motion.ul
              initial={{ opacity: 0, y: -4, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.98, transition: { duration: 0.12 } }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className="glass-window absolute right-0 z-20 mt-1.5 w-full min-w-[132px] overflow-hidden rounded-lg p-1"
            >
              {options.map((opt) => (
                <li key={opt}>
                  <button
                    type="button"
                    onClick={() => {
                      onChange(opt);
                      setOpen(false);
                    }}
                    className={clsx(
                      'flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-left text-sm transition-colors',
                      opt === value
                        ? 'bg-[rgba(200,212,162,0.10)] text-[#c8d4a2]'
                        : 'text-[#a3b27a] hover:bg-[rgba(200,212,162,0.05)] hover:text-[#c8d4a2]',
                    )}
                  >
                    {opt}
                    {opt === value && (
                      <svg viewBox="0 0 16 16" className="h-3.5 w-3.5 text-[#8cb369]" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M3 8.5l3.2 3L13 4.5" />
                      </svg>
                    )}
                  </button>
                </li>
              ))}
            </motion.ul>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function Slider({
  value,
  min,
  max,
  onChange,
  display,
}: {
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  display: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="flex w-[180px] items-center gap-3">
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="olive-range"
        style={{
          background: `linear-gradient(90deg, #8cb369 ${pct}%, rgba(200,212,162,0.12) ${pct}%)`,
        }}
      />
      <span className="w-8 text-right font-mono text-xs tabular-nums text-[#a3b27a]">
        {display}
      </span>
    </div>
  );
}

function Checkbox({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-2.5 text-sm text-[#a3b27a] transition-colors hover:text-[#c8d4a2]"
    >
      <span
        className={clsx(
          'flex h-4 w-4 items-center justify-center rounded-[5px] border transition-colors duration-150',
          checked
            ? 'border-[#8cb369] bg-[#8cb369]'
            : 'border-[rgba(200,212,162,0.20)] bg-transparent',
        )}
      >
        {checked && (
          <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="#1a1f14" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 8.5l3.2 3L13 4.5" />
          </svg>
        )}
      </span>
      {label}
    </button>
  );
}

const ACCENTS = ['#c8d4a2', '#8cb369', '#7a9cbf', '#d4a843', '#c75d5d'];

function AccentPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-2.5">
      {ACCENTS.map((c) => (
        <button
          key={c}
          type="button"
          aria-label={`Accent ${c}`}
          onClick={() => onChange(c)}
          className={clsx(
            'h-[18px] w-[18px] rounded-full transition-all duration-150',
            value === c
              ? 'scale-110 ring-2 ring-[#c8d4a2] ring-offset-2 ring-offset-[#1a1f14]'
              : 'opacity-70 hover:scale-110 hover:opacity-100',
          )}
          style={{ background: c }}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Sections                                                           */
/* ------------------------------------------------------------------ */

function GeneralSection({
  settings,
  patch,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  return (
    <div className="flex flex-col gap-5">
      <Card title="Appearance">
        <Row label="Theme">
          <Dropdown
            value={settings.theme}
            options={['Auto', 'Light', 'Dark']}
            onChange={(v) => patch({ theme: v })}
          />
        </Row>
        <Row label="Accent color">
          <AccentPicker value={settings.accent} onChange={(v) => patch({ accent: v })} />
        </Row>
        <ToggleRow
          label="Animations"
          description="Interface motion and transitions"
          checked={settings.animations}
          onChange={(v) => patch({ animations: v })}
        />
      </Card>
      <Card title="Behavior">
        <Row label="Language">
          <Dropdown
            value={settings.language}
            options={['English (US)', 'Deutsch', 'Français', '日本語']}
            onChange={(v) => patch({ language: v })}
          />
        </Row>
        <Row label="After compress">
          <Dropdown
            value={settings.afterCompress}
            options={['Close dialog', 'Keep open', 'Open folder']}
            onChange={(v) => patch({ afterCompress: v })}
          />
        </Row>
        <ToggleRow
          label="Sound effects"
          description="Subtle sounds for completed operations"
          checked={settings.soundEffects}
          onChange={(v) => patch({ soundEffects: v })}
        />
      </Card>
    </div>
  );
}

function CompressionSection({
  settings,
  patch,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  return (
    <div className="flex flex-col gap-5">
      <Card title="Defaults">
        <Row label="Default format">
          <Dropdown
            value={settings.defaultFormat}
            options={['ZIP', '7z', 'TAR', 'RAR']}
            onChange={(v) => patch({ defaultFormat: v })}
          />
        </Row>
        <Row label="Compression level" description="Higher is smaller but slower">
          <Slider
            value={settings.compressionLevel}
            min={1}
            max={9}
            onChange={(v) => patch({ compressionLevel: v })}
            display={String(settings.compressionLevel)}
          />
        </Row>
        <Row label="Worker threads" description="Parallel compression threads">
          <Slider
            value={settings.threadCount}
            min={1}
            max={16}
            onChange={(v) => patch({ threadCount: v })}
            display={String(settings.threadCount)}
          />
        </Row>
      </Card>
      <Card title="Storage">
        <Row label="Temporary directory" description="Used for split & shred operations">
          <div className="flex items-center gap-2">
            <span className="max-w-[220px] truncate rounded-lg border border-[rgba(200,212,162,0.10)] bg-[rgba(0,0,0,0.22)] px-3 py-1.5 font-mono text-xs text-[#a3b27a]">
              {settings.tempDir}
            </span>
            <GhostButton className="h-8 px-3 py-0 text-xs">Browse</GhostButton>
          </div>
        </Row>
      </Card>
    </div>
  );
}

function IntegrationSection({
  settings,
  patch,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  return (
    <div className="flex flex-col gap-5">
      <Card title="Shell">
        <ToggleRow
          label="Context menu integration"
          description="Show ReformAny actions in the right-click menu"
          checked={settings.contextMenu}
          onChange={(v) => patch({ contextMenu: v })}
        />
        <ToggleRow
          label="Add to system PATH"
          description="Run reformany from any terminal"
          checked={settings.addToPath}
          onChange={(v) => patch({ addToPath: v })}
        />
        <ToggleRow
          label="Default app for archives"
          description="Open .zip, .7z and .tar with ReformAny"
          checked={settings.defaultApp}
          onChange={(v) => patch({ defaultApp: v })}
        />
      </Card>
      <Card title="File associations">
        <div className="flex flex-wrap gap-x-6 gap-y-3">
          {Object.entries(settings.associations).map(([ext, on]) => (
            <Checkbox
              key={ext}
              label={`.${ext.toLowerCase()}`}
              checked={on}
              onChange={(v) =>
                patch({ associations: { ...settings.associations, [ext]: v } })
              }
            />
          ))}
        </div>
      </Card>
    </div>
  );
}

function AdvancedSection({
  settings,
  patch,
}: {
  settings: Settings;
  patch: (p: Partial<Settings>) => void;
}) {
  const toast = useToast();
  return (
    <div className="flex flex-col gap-5">
      <Card title="Diagnostics">
        <Row label="Logging level">
          <Dropdown
            value={settings.loggingLevel}
            options={['Error', 'Warning', 'Info', 'Debug']}
            onChange={(v) => patch({ loggingLevel: v })}
          />
        </Row>
        <ToggleRow
          label="Automatic updates"
          description="Check for new versions on launch"
          checked={settings.autoUpdate}
          onChange={(v) => patch({ autoUpdate: v })}
        />
        <ToggleRow
          label="Anonymous telemetry"
          description="Help improve ReformAny. No file data is ever sent."
          checked={settings.telemetry}
          onChange={(v) => patch({ telemetry: v })}
        />
      </Card>
      <Card title="Maintenance">
        <Row label="Cache" description="Temporary files from previous operations">
          <GhostButton
            className="h-8 px-3 py-0 text-xs"
            onClick={() => toast.success('Cache cleared', { detail: '212 MB reclaimed' })}
          >
            Clear cache
          </GhostButton>
        </Row>
        <Row label="Reset" description="Restore all preferences to defaults">
          <GhostButton
            className="h-8 px-3 py-0 text-xs hover:border-[rgba(199,93,93,0.4)] hover:text-[#c75d5d]"
            onClick={() => toast.warning('Preferences reset', { detail: 'Defaults restored' })}
          >
            Reset to defaults
          </GhostButton>
        </Row>
      </Card>
    </div>
  );
}

function AboutSection() {
  const toast = useToast();
  return (
    <div className="flex flex-col gap-5">
      <Card title="ReformAny">
        <div className="flex items-center gap-4">
          <Logo size={48} />
          <div>
            <p className="text-base font-semibold text-[#c8d4a2]">ReformAny</p>
            <p className="mt-0.5 text-xs text-[#7d8c5c]">
              Version 1.0.0 · Build 2026.1.4 (stable)
            </p>
          </div>
        </div>
        <div className="h-px bg-[rgba(200,212,162,0.06)]" />
        <div className="grid grid-cols-[110px_1fr] gap-y-2 text-xs">
          <span className="text-[#7d8c5c]">License</span>
          <span className="text-[#a3b27a]">MIT</span>
          <span className="text-[#7d8c5c]">Core</span>
          <span className="font-mono text-[#a3b27a]">Rust · Tauri 2</span>
          <span className="text-[#7d8c5c]">Website</span>
          <button
            type="button"
            onClick={() => toast.info('Opening website', { detail: 'reformany.app' })}
            className="text-left text-[#a3b27a] underline decoration-[rgba(200,212,162,0.25)] underline-offset-4 transition-colors hover:text-[#c8d4a2]"
          >
            reformany.app
          </button>
          <span className="text-[#7d8c5c]">Source</span>
          <button
            type="button"
            onClick={() => toast.info('Opening repository', { detail: 'github.com/reformany' })}
            className="text-left text-[#a3b27a] underline decoration-[rgba(200,212,162,0.25)] underline-offset-4 transition-colors hover:text-[#c8d4a2]"
          >
            github.com/reformany
          </button>
        </div>
        <div className="pt-1">
          <PrimaryButton
            className="px-4 py-2 text-xs"
            onClick={() => toast.success("You're up to date", { detail: 'v1.0.0 is the latest release' })}
          >
            Check for updates
          </PrimaryButton>
        </div>
      </Card>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  PreferencesPanel                                                   */
/* ------------------------------------------------------------------ */

export function PreferencesPanel() {
  const [section, setSection] = useState<SectionId>('general');
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);

  const patch = (p: Partial<Settings>) => setSettings((s) => ({ ...s, ...p }));

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <nav className="flex w-[180px] shrink-0 flex-col gap-0.5 border-r border-[rgba(200,212,162,0.06)] p-3">
        {SECTIONS.map((s) => {
          const active = section === s.id;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setSection(s.id)}
              className={clsx(
                'relative flex items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm transition-colors duration-150',
                active
                  ? 'bg-[rgba(200,212,162,0.08)] text-[#c8d4a2]'
                  : 'text-[#7d8c5c] hover:bg-[rgba(200,212,162,0.04)] hover:text-[#a3b27a]',
              )}
            >
              {active && (
                <motion.span
                  layoutId="prefs-active-bar"
                  className="absolute left-0 top-1/2 h-4 w-[2px] -translate-y-1/2 rounded-full bg-[#c8d4a2]"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}
              <svg viewBox="0 0 24 24" className="h-4 w-4 shrink-0" fill="none">
                {s.icon}
              </svg>
              {s.label}
            </button>
          );
        })}
      </nav>

      {/* Content */}
      <div className="min-w-0 flex-1 overflow-y-auto p-6">
        <h2 className="mb-5 text-lg font-semibold tracking-tight text-[#c8d4a2]">
          {SECTIONS.find((s) => s.id === section)?.label} Settings
        </h2>
        <AnimatePresence mode="wait">
          <motion.div
            key={section}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="max-w-[560px]"
          >
            {section === 'general' && <GeneralSection settings={settings} patch={patch} />}
            {section === 'compression' && (
              <CompressionSection settings={settings} patch={patch} />
            )}
            {section === 'integration' && (
              <IntegrationSection settings={settings} patch={patch} />
            )}
            {section === 'advanced' && <AdvancedSection settings={settings} patch={patch} />}
            {section === 'about' && <AboutSection />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
