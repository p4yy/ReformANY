import { useId } from 'react';

interface LogoProps {
  size?: number;
  className?: string;
}

/**
 * ReformAny app icon — sage gradient rounded square with a dark "R"
 * letterform (stem, bowl, leg) drawn as a single stroked path.
 */
export function Logo({ size = 32, className }: LogoProps) {
  const uid = useId().replace(/:/g, '');
  const gradId = `ra-grad-${uid}`;
  const sheenId = `ra-sheen-${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      className={className}
      role="img"
      aria-label="ReformAny"
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#d9e3b4" />
          <stop offset="55%" stopColor="#a3b27a" />
          <stop offset="100%" stopColor="#7d8c5c" />
        </linearGradient>
        <linearGradient id={sheenId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect
        x="1.5"
        y="1.5"
        width="45"
        height="45"
        rx="12"
        fill={`url(#${gradId})`}
        stroke="rgba(200,212,162,0.35)"
        strokeWidth="1"
      />
      <rect x="1.5" y="1.5" width="45" height="22.5" rx="12" fill={`url(#${sheenId})`} />
      <path
        d="M17 34 V14 h8.5 a6.5 6.5 0 0 1 0 13 H17"
        fill="none"
        stroke="#1a1f14"
        strokeWidth="4.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M23 27 L31.5 34"
        fill="none"
        stroke="#1a1f14"
        strokeWidth="4.4"
        strokeLinecap="round"
      />
    </svg>
  );
}
