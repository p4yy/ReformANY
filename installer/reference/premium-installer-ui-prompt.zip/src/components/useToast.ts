import { useContext } from 'react';
import { ToastContext } from './ToastProvider';

/**
 * Toast hook — returns variant helpers:
 *
 *   const toast = useToast();
 *   toast.success('Path copied to clipboard', { detail: 'C:\\Users\\...' });
 *   toast.error('Operation failed', { detail: 'Permission denied', duration: 5000 });
 */
export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within a ToastProvider');
  return ctx;
}
