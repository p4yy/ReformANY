import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { clsx } from 'clsx';
import { GhostButton } from './ui';

export interface ConfirmationDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  description?: string;
  files: { name: string; size: string }[];
  confirmationWord?: string;
  actionLabel?: string;
}

/**
 * Confirmation dialog for destructive actions (e.g. Shred).
 * Serious but calm — the destructive action unlocks only when the
 * user types the confirmation word exactly.
 */
export function ConfirmationDialog({
  open,
  onClose,
  onConfirm,
  title = "This can't be undone.",
  description = 'files will be permanently destroyed using secure overwrite (3-pass DoD method). Original data cannot be recovered.',
  files,
  confirmationWord = 'SHRED',
  actionLabel = 'Shred Forever',
}: ConfirmationDialogProps) {
  const [input, setInput] = useState('');
  const confirmed = input === confirmationWord;

  useEffect(() => {
    if (open) setInput('');
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Enter' && confirmed) onConfirm();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, confirmed, onClose, onConfirm]);

  const shown = files.slice(0, 3);
  const remaining = files.length - shown.length;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.15 } }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: -10, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: -6, opacity: 0, scale: 0.98, transition: { duration: 0.15 } }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-window noise w-[400px] max-w-[calc(100vw-32px)] p-6"
          >
            {/* Warning icon */}
            <div className="flex justify-center">
              <span className="animate-pulse-soft flex h-12 w-12 items-center justify-center rounded-full border border-[rgba(212,168,67,0.35)] bg-[rgba(212,168,67,0.10)] shadow-[0_0_24px_-6px_rgba(212,168,67,0.5)]">
                <svg
                  viewBox="0 0 24 24"
                  className="h-6 w-6"
                  fill="none"
                  stroke="#d4a843"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 3.5L22 20H2L12 3.5z" />
                  <path d="M12 10v4.5" />
                  <circle cx="12" cy="17.2" r="0.7" fill="#d4a843" stroke="none" />
                </svg>
              </span>
            </div>

            <h2 className="mt-4 text-center text-xl font-semibold tracking-tight text-[#c8d4a2]">
              {title}
            </h2>
            <p className="mt-2 text-center text-sm leading-relaxed text-[#a3b27a]">
              <span className="font-medium text-[#c8d4a2]">{files.length}</span>{' '}
              {description}
            </p>

            {/* File list */}
            <div className="mt-5 rounded-lg border border-[rgba(200,212,162,0.04)] bg-[rgba(0,0,0,0.2)] p-2">
              {shown.map((f) => (
                <div
                  key={f.name}
                  className="flex items-center gap-2.5 rounded-md px-2 py-1.5"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="h-4 w-4 shrink-0 text-[#7d8c5c]"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinejoin="round"
                  >
                    <path d="M6 2.5h8L19 7.5v14H6v-19z" />
                    <path d="M14 2.5v5h5" />
                  </svg>
                  <span className="flex-1 truncate text-xs text-[#a3b27a]">
                    {f.name}
                  </span>
                  <span className="font-mono text-[11px] text-[#7d8c5c]">{f.size}</span>
                </div>
              ))}
              {remaining > 0 && (
                <p className="px-2 pb-1 pt-1.5 text-xs text-[#7d8c5c]">
                  and {remaining} more file{remaining === 1 ? '' : 's'}
                </p>
              )}
            </div>

            {/* Confirmation input */}
            <label className="mt-5 block text-xs font-medium text-[#7d8c5c]">
              Type <span className="font-mono text-[#c8d4a2]">"{confirmationWord}"</span> to
              confirm:
            </label>
            <input
              autoFocus
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={confirmationWord}
              spellCheck={false}
              autoComplete="off"
              className={clsx(
                'mt-2 w-full rounded-lg border bg-[rgba(0,0,0,0.25)] px-3.5 py-2.5 font-mono text-sm tracking-widest text-[#c8d4a2] outline-none transition-colors duration-200 placeholder:text-[#7d8c5c]/50',
                confirmed
                  ? 'border-[rgba(140,179,105,0.55)]'
                  : 'border-[rgba(199,93,93,0.35)] focus:border-[rgba(199,93,93,0.6)]',
              )}
            />

            {/* Actions */}
            <div className="mt-6 flex items-center justify-between">
              <GhostButton onClick={onClose}>Cancel</GhostButton>
              <button
                type="button"
                disabled={!confirmed}
                onClick={onConfirm}
                className={clsx(
                  'rounded-lg px-5 py-2.5 text-sm font-medium text-[#1a1f14] transition-all duration-200 active:scale-[0.97]',
                  confirmed
                    ? 'animate-pulse-soft bg-[#c75d5d] hover:bg-[#d46b6b]'
                    : 'pointer-events-none bg-[#c75d5d] opacity-40',
                )}
              >
                {actionLabel}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
