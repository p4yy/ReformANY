import { motion } from 'framer-motion';
import { clsx } from 'clsx';

interface ToggleProps {
  checked: boolean;
  onChange?: (value: boolean) => void;
  disabled?: boolean;
  label?: string;
}

/**
 * iOS-style toggle switch — 44×24 capsule, 20px thumb with drop shadow,
 * spring physics on the thumb (stiffness 500, damping 30).
 */
export function Toggle({ checked, onChange, disabled }: ToggleProps) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange?.(!checked)}
      className={clsx(
        'relative flex h-6 w-11 shrink-0 items-center rounded-full px-[2px] transition-colors duration-200',
        checked ? 'bg-[#8cb369]' : 'bg-[rgba(200,212,162,0.10)]',
        disabled && 'pointer-events-none opacity-40',
      )}
    >
      <motion.span
        layout
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        className={clsx(
          'h-5 w-5 rounded-full bg-[#eef2df] shadow-[0_2px_6px_rgba(0,0,0,0.45),0_0_0_1px_rgba(0,0,0,0.08)]',
          checked ? 'ml-auto' : 'ml-0',
        )}
      />
    </button>
  );
}

interface ToggleRowProps extends ToggleProps {
  description?: string;
}

/** Label + optional description on the left, toggle on the right. */
export function ToggleRow({
  checked,
  onChange,
  disabled,
  label,
  description,
}: ToggleRowProps) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-medium text-[#c8d4a2]">{label}</p>
        {description && (
          <p className="mt-0.5 text-xs leading-relaxed text-[#7d8c5c]">
            {description}
          </p>
        )}
      </div>
      <Toggle checked={checked} onChange={onChange} disabled={disabled} />
    </div>
  );
}
