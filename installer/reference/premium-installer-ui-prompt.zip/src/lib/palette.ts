/** ReformAny design tokens — olive / dark-earth palette */
export const palette = {
  bg: {
    primary: '#1a1f14',
    secondary: '#232a1c',
    tertiary: '#2d3524',
    elevated: '#363f2c',
  },
  accent: {
    primary: '#c8d4a2',
    secondary: '#a3b27a',
    tertiary: '#7d8c5c',
    ghost: 'rgba(200, 212, 162, 0.08)',
    glow: 'rgba(200, 212, 162, 0.15)',
  },
  semantic: {
    success: '#8cb369',
    warning: '#d4a843',
    error: '#c75d5d',
    info: '#7a9cbf',
  },
  border: {
    subtle: 'rgba(200, 212, 162, 0.06)',
    default: 'rgba(200, 212, 162, 0.12)',
    strong: 'rgba(200, 212, 162, 0.20)',
  },
} as const;

export const fontStack =
  "-apple-system, BlinkMacSystemFont, 'Segoe UI', Inter, system-ui, sans-serif";
